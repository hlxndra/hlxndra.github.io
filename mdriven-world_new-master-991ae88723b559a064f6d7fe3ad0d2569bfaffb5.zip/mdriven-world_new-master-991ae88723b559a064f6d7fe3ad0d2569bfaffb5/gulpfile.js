'use strict';

var gulp            = require("gulp");
var sass            = require("gulp-sass");
var sassGlob        = require('gulp-sass-glob');
var plumber         = require('gulp-plumber');
var postcss         = require('gulp-postcss');
var autoprefixer    = require('autoprefixer');
var mqpacker        = require('css-mqpacker');
var minify          = require('gulp-csso');
var rename          = require('gulp-rename');
var imagemin        = require('gulp-imagemin');
var uglify          = require('gulp-uglify');
var gutil           = require('gulp-util');
var ftp             = require('vinyl-ftp');
var del             = require('del');
var browserSync     = require('browser-sync');


// Local server start
gulp.task('server', function () {
	browserSync({
		server: {
			baseDir: 'src'
		},
		notify: false
	});
});

// Convert Sass to CSS + Autoprefixer + Goupping media queries + Minifier
gulp.task("style", function () {
    gulp.src("src/css/sass/style.scss")
    .pipe(plumber())
    .pipe(sassGlob())
    .pipe(sass())
    .pipe(postcss([
      autoprefixer({browsers: 'last 5 versions'}),
      mqpacker({sort: true})
    ]))
    .pipe(minify())
    .pipe(rename({suffix: '.min', prefix: ''}))
    .pipe(gulp.dest("src/css"))
    .pipe(browserSync.reload({stream: true}));
});

// Minifier scripts.js file
gulp.task("scripts", function() {
  gulp.src("src/js/scripts.js")
  .pipe(uglify())
  .pipe(rename({suffix: '.min', prefix: ''}))
  .pipe(gulp.dest("src/js"))
  .pipe(browserSync.reload({stream: true}));
});

// Optimization of images
gulp.task("images", function() {
    gulp.src("src/img/**/*")
    .pipe(imagemin([
      imagemin.jpegtran({progressive: true}),
      imagemin.optipng({optimizationLevel: 3})
    ]))
});

// Watch task during the developing process
gulp.task('watch', ['server', 'style', 'scripts'], function() {
    gulp.watch('src/css/**/*.scss', ['style']);
    gulp.watch('src/js/*.js', ['scripts']);
    gulp.watch('src/*.html', browserSync.reload);
});

// Build task for production
gulp.task("build", ['style', 'images', 'scripts'], function() {
  del.sync("build");
  gulp.src("src/css/*.css").pipe(gulp.dest("build/css"))
  gulp.src("src/fonts/**/*").pipe(gulp.dest("build/fonts"))
  gulp.src("src/js/**/*.min.js").pipe(gulp.dest("build/js"))
  gulp.src("src/img/**/*").pipe(gulp.dest("build/img"))
  gulp.src("src/*.html").pipe(gulp.dest("build"));
  gulp.src("src/.htaccess").pipe(gulp.dest("build"));
  gulp.src("src/libs/**/*").pipe(gulp.dest('build/libs'))
});

// Deploy on server
gulp.task("deploy", function() {

  var conn = ftp.create({
    host: 'hostname.com',
    user: 'username',
    password: 'userpassword',
    parallel: 10,
    log: gutil.log
  });

  var globs = [
    'build/**',
    'build/.htaccess',
  ];
  return gulp.src(globs, {buffer: false})
  .pipe(conn.dest('/path/to/folder/on/server'));
  
});

// Set the default gulp task
gulp.task("default", ['watch']);
